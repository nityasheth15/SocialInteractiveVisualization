Read Me:
The assignment is submitted by Nitya Sheth [ASU ID: 12086629840].


I have also hosted the assignment online on following link:
1) http://www.public.asu.edu/~ndsheth1/index.html
(the excel sheet used in this is truncated, just for you to have a quick look on the web page.)

2) http://www.public.asu.edu/~ndsheth1/index_withAllDataFile.html
-This link displays all the correct data (having the 67mb 'class_operation' working, which takes approx 30-40 seconds to open if you are working in low internet speed).

3) I have submitted all the files on blackboard too. You will require server to run code in Chrome. 
-If you have python installed on machine just type 
python -m SimpleHTTPServer 8888 & 
and run
http://localhost:8888/Desktop/D3/index_withAllDataFile.html 
after putting all the files in a folder named D3 in  Desktop.
Please note that locally it will load the files in just a couple of seconds, hence no need to use index.html

